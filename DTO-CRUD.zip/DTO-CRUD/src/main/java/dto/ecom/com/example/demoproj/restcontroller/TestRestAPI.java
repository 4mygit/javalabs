package dto.ecom.com.example.demoproj.restcontroller;

import dto.ecom.com.example.demoproj.dto.CategoryDTO;
import dto.ecom.com.example.demoproj.dto.CategoryOutBoundDTO;
import dto.ecom.com.example.demoproj.entity.Category;
import dto.ecom.com.example.demoproj.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/api")
public class TestRestAPI {
    private CategoryService categoryService;
    @Autowired
    public TestRestAPI(CategoryService thecategoryService){
        categoryService = thecategoryService;
    }
    @GetMapping("/testapi")
        public String getTestApi(){
        return "This is test for API";
    }

    @GetMapping("/category")
    public List<CategoryDTO> findAll(){
        return categoryService.findAll();
    }

    @GetMapping("/category/{empid}")
    public Category findById(@PathVariable int empid){
        Category  theCategory = categoryService.findById(empid);
        return categoryService.findById(empid);
    }

    @PostMapping("/addcat")
    public Category addCategory(@RequestBody Category theCategory) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        theCategory.setId(0);

        Category dbEmployee = categoryService.save(theCategory);

        return dbEmployee;
    }

    @PostMapping("/addcatdto")
    public Category addCategoryDTO(@RequestBody CategoryOutBoundDTO theCategoryOBDTO) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        //theCategoryOBDTO.setId(0);
        Category theCategory = new Category(); // The entity model class object
        theCategory.setCategory(theCategoryOBDTO.getCategory());
        theCategory.setType(theCategoryOBDTO.getType());

        Category dbEmployee = categoryService.save(theCategory);

        return dbEmployee;
    }

    @PatchMapping("/updtemployee/{id}")
    public Category updateCategoryDTO(@PathVariable int id, @RequestBody CategoryOutBoundDTO theCategoryOBDTO) {

        //theCategoryOBDTO.setId(0);
       // Category theCategory = new Category();
        //theCategory.setId(theCategoryOBDTO.getId());
        //theCategory.setCategory(theCategoryOBDTO.getCategory());
        //theCategory.setType(theCategoryOBDTO.getType());
        Category dbEmployee = categoryService.update(id, theCategoryOBDTO);

        return dbEmployee;
    }

}

