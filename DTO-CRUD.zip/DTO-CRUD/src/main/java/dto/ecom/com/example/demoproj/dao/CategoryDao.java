package dto.ecom.com.example.demoproj.dao;

import dto.ecom.com.example.demoproj.entity.Category;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CategoryDao implements CategoryDaoInt{
private EntityManager entityManager;

@Autowired
    public CategoryDao(EntityManager theEntityManager){
    entityManager = theEntityManager;
}

@Override
    public List<Category> findAll(){
    TypedQuery<Category> theQuery =
            entityManager.createQuery("from Category", Category.class);
    List<Category> categories = theQuery.getResultList();
    return categories;
}
   public Category findByCategoryId(int theId){
    Category theCategory = entityManager.find(Category.class,theId);
    return theCategory;
   }

   public Category save(Category theCategory){
    Category dbCategory = entityManager.merge(theCategory);
    return dbCategory;
   }


 //   Category update(Category theCategory){

   // }


}
