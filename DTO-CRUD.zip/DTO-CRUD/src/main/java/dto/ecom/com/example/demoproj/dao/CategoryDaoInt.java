package dto.ecom.com.example.demoproj.dao;

import dto.ecom.com.example.demoproj.entity.Category;

import java.util.List;

public interface CategoryDaoInt {
    List<Category> findAll();
    Category findByCategoryId(int theId);
    Category save(Category theCategory);
    //Category update(Category theCategory);
    //void deleteById(int theId);
}
