package dto.ecom.com.example.demoproj.service;

import dto.ecom.com.example.demoproj.dto.CategoryDTO;
import dto.ecom.com.example.demoproj.entity.Category;

import java.util.List;

public interface CategoryServicesInt{
    List<CategoryDTO> findAll();

   // void deleteCategoryById(int categoryId);

    Category findById(int theCategory);

    Category save(Category theCategory);

}

