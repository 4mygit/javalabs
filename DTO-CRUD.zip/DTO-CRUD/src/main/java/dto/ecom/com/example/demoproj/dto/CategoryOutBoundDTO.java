package dto.ecom.com.example.demoproj.dto;

public class CategoryOutBoundDTO {

    private String category;
    private int id;
    private String type;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CategoryOutBoundDTO() {
    }

    public CategoryOutBoundDTO(String category) {
        this.category = category;
     }

    public String getCategory() {
        return category;
    }


    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}