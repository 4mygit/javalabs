package dto.ecom.com.example.demoproj.dto;

public class CategoryDTO {



        private String category;
        private String type;

        public CategoryDTO(String category, String type) {
            this.category = category;
            this.type = type;
        }

        public String getCategory() {
            return category;
        }

        public String getType() {
            return type;
        }

    }

