package dto.ecom.com.example.demoproj.service;

import dto.ecom.com.example.demoproj.dao.CategoryDao;
import dto.ecom.com.example.demoproj.dto.CategoryDTO;
import dto.ecom.com.example.demoproj.dto.CategoryOutBoundDTO;
import dto.ecom.com.example.demoproj.entity.Category;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryService implements CategoryServicesInt{
    private CategoryDao categoryDao;

    public CategoryService(CategoryDao theCategoryDao){
        categoryDao = theCategoryDao;
    }

    public List<CategoryDTO> findAll(){
         List<Category> categories = categoryDao.findAll();
           return categories.stream()
                   .map(category -> {
                       String categoryName = category.getCategory();
                       String typeName = category.getType();
                       return new CategoryDTO(categoryName, typeName);

                   }).collect(Collectors.toList());
       // return categoryDao.findAll();
    }

    public Category findById(int theCategory){
        return  categoryDao.findByCategoryId(theCategory);
    }

    @Transactional
    public Category save(Category theCategory){
        return categoryDao.save(theCategory);
    }

    @Transactional
    public Category update(int id, CategoryOutBoundDTO theCategoryOBDT){
       // Category dbCategory = categoryDao.findByCategoryId(theCategoryOBDT.getId());
        Category dbCategory = categoryDao.findByCategoryId(id);
        if (theCategoryOBDT.getCategory() != null) {
            dbCategory.setCategory(theCategoryOBDT.getCategory());
        }
        if (theCategoryOBDT.getType() != null) {
            dbCategory.setType(theCategoryOBDT.getType());
            System.out.println(theCategoryOBDT.getType());
        }else{
            System.out.println(theCategoryOBDT.getType());

        }

        return categoryDao.save(dbCategory);


    }


}
