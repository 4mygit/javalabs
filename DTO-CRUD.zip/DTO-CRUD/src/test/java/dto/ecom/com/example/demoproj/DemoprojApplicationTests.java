package dto.ecom.com.example.demoproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
